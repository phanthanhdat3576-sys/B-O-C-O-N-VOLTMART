using ElectronicPartsShop.Data;
using ElectronicPartsShop.Helpers;
using ElectronicPartsShop.Models;
using ElectronicPartsShop.ViewModels;
using Microsoft.AspNetCore.Mvc;
namespace ElectronicPartsShop.Controllers;
public class CheckoutController(AppDbContext db) : Controller
{
 const string Key="CART";
 List<CartItem> Cart=>HttpContext.Session.GetObject<List<CartItem>>(Key)??[];
 [HttpGet] public IActionResult Index(){if(!Cart.Any())return RedirectToAction("Index","Cart"); ViewBag.Cart=Cart; return View(new CheckoutVm());}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Index(CheckoutVm vm)
 {var cart=Cart; ViewBag.Cart=cart; if(!cart.Any()){ModelState.AddModelError("","Giỏ hàng đang trống.");return View(vm);} if(!ModelState.IsValid)return View(vm);
  var ids=cart.Select(x=>x.ProductId).ToList(); var products=await db.Products.Where(x=>ids.Contains(x.Id)).ToDictionaryAsync(x=>x.Id);
  foreach(var item in cart){ if(!products.TryGetValue(item.ProductId,out var p)||p.Stock<item.Quantity){ModelState.AddModelError("",$"Sản phẩm {item.Name} không đủ tồn kho.");return View(vm);} }
  var order=new Order{CustomerName=vm.CustomerName,Phone=vm.Phone,Address=vm.Address,Email=vm.Email,Note=vm.Note,TotalAmount=cart.Sum(x=>x.LineTotal)};
  foreach(var item in cart){var p=products[item.ProductId];p.Stock-=item.Quantity;order.Items.Add(new OrderItem{ProductId=p.Id,ProductName=p.Name,UnitPrice=item.Price,Quantity=item.Quantity});}
  db.Orders.Add(order);await db.SaveChangesAsync();HttpContext.Session.Remove(Key);return RedirectToAction(nameof(Success),new{id=order.Id});}
 public async Task<IActionResult> Success(int id){var o=await db.Orders.FindAsync(id);return o is null?NotFound():View(o);}
}
