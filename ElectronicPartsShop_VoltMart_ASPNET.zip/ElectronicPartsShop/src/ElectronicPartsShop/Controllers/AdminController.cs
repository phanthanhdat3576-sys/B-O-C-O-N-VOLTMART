using ElectronicPartsShop.Data;
using ElectronicPartsShop.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ElectronicPartsShop.Controllers;
public class AdminController(AppDbContext db, IConfiguration config) : Controller
{
 bool IsAdmin => HttpContext.Session.GetString("ADMIN") == "1";
 IActionResult? Guard()=>IsAdmin?null:RedirectToAction(nameof(Login));
 public IActionResult Login()=>View();
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Login(string username,string password)
 { if(username==config["Admin:Username"] && password==config["Admin:Password"]){HttpContext.Session.SetString("ADMIN","1");return RedirectToAction(nameof(Dashboard));} ViewBag.Error="Tài khoản hoặc mật khẩu chưa đúng.";return View(); }
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Logout(){HttpContext.Session.Remove("ADMIN");return RedirectToAction("Index","Home");}
 public async Task<IActionResult> Dashboard(){if(Guard() is { } r)return r; var today=DateTime.UtcNow.Date;ViewBag.ProductCount=await db.Products.CountAsync();ViewBag.OrderCount=await db.Orders.CountAsync();ViewBag.Revenue=await db.Orders.Where(x=>x.Status!=OrderStatus.Cancelled).SumAsync(x=>(decimal?)x.TotalAmount)??0;ViewBag.TodayOrders=await db.Orders.Where(x=>x.CreatedAt>=today).CountAsync();return View(await db.Orders.Include(x=>x.Items).OrderByDescending(x=>x.CreatedAt).Take(8).ToListAsync());}
 public async Task<IActionResult> Products(){if(Guard() is { } r)return r;return View(await db.Products.Include(x=>x.Category).OrderByDescending(x=>x.Id).ToListAsync());}
 public async Task<IActionResult> CreateProduct(){if(Guard() is { } r)return r;ViewBag.Categories=await db.Categories.ToListAsync();return View(new Product{IsActive=true});}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> CreateProduct(Product p){if(Guard() is { } r)return r;if(!ModelState.IsValid){ViewBag.Categories=await db.Categories.ToListAsync();return View(p);}db.Products.Add(p);await db.SaveChangesAsync();TempData["Success"]="Đã thêm sản phẩm.";return RedirectToAction(nameof(Products));}
 public async Task<IActionResult> EditProduct(int id){if(Guard() is { } r)return r;var p=await db.Products.FindAsync(id);if(p is null)return NotFound();ViewBag.Categories=await db.Categories.ToListAsync();return View(p);}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> EditProduct(Product p){if(Guard() is { } r)return r;if(!ModelState.IsValid){ViewBag.Categories=await db.Categories.ToListAsync();return View(p);}db.Update(p);await db.SaveChangesAsync();TempData["Success"]="Đã cập nhật sản phẩm.";return RedirectToAction(nameof(Products));}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> DeleteProduct(int id){if(Guard() is { } r)return r;var p=await db.Products.FindAsync(id);if(p!=null){p.IsActive=false;await db.SaveChangesAsync();}return RedirectToAction(nameof(Products));}
 public async Task<IActionResult> Orders(){if(Guard() is { } r)return r;return View(await db.Orders.Include(x=>x.Items).OrderByDescending(x=>x.CreatedAt).ToListAsync());}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> UpdateOrderStatus(int id,OrderStatus status){if(Guard() is { } r)return r;var o=await db.Orders.FindAsync(id);if(o!=null){o.Status=status;await db.SaveChangesAsync();}return RedirectToAction(nameof(Orders));}
 public async Task<IActionResult> Categories(){if(Guard() is { } r)return r;return View(await db.Categories.Include(x=>x.Products).OrderBy(x=>x.Name).ToListAsync());}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> CreateCategory(Category c){if(Guard() is { } r)return r;if(ModelState.IsValid){db.Categories.Add(c);await db.SaveChangesAsync();}return RedirectToAction(nameof(Categories));}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> DeleteCategory(int id){if(Guard() is { } r)return r;var c=await db.Categories.Include(x=>x.Products).FirstOrDefaultAsync(x=>x.Id==id);if(c!=null&& !c.Products.Any()){db.Categories.Remove(c);await db.SaveChangesAsync();}else TempData["Error"]="Không thể xoá danh mục đang có sản phẩm.";return RedirectToAction(nameof(Categories));}
}
