using ElectronicPartsShop.Data;
using ElectronicPartsShop.Helpers;
using ElectronicPartsShop.Models;
using Microsoft.AspNetCore.Mvc;
namespace ElectronicPartsShop.Controllers;
public class CartController(AppDbContext db) : Controller
{
 const string Key="CART";
 List<CartItem> Cart => HttpContext.Session.GetObject<List<CartItem>>(Key) ?? [];
 void Save(List<CartItem> c)=>HttpContext.Session.SetObject(Key,c);
 public IActionResult Index()=>View(Cart);
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Add(int productId,int quantity=1,string? returnUrl=null)
 { var p=await db.Products.FindAsync(productId); if(p is null||!p.IsActive){TempData["Error"]="Sản phẩm không tồn tại."; return RedirectToAction("Index","Products");} var cart=Cart; var i=cart.FirstOrDefault(x=>x.ProductId==productId); if(i is null) cart.Add(new CartItem{ProductId=p.Id,Name=p.Name,Price=p.Price,Quantity=Math.Clamp(quantity,1,Math.Max(1,p.Stock)),ImageUrl=p.ImageUrl}); else i.Quantity=Math.Min(i.Quantity+quantity,p.Stock); Save(cart); TempData["Success"]="Đã thêm sản phẩm vào giỏ hàng."; return LocalRedirect(string.IsNullOrWhiteSpace(returnUrl)?Url.Action("Index")!:returnUrl); }
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Update(int productId,int quantity){var cart=Cart; var i=cart.FirstOrDefault(x=>x.ProductId==productId); if(i!=null){if(quantity<=0)cart.Remove(i);else i.Quantity=quantity;Save(cart);} return RedirectToAction(nameof(Index));}
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Remove(int productId){var c=Cart; c.RemoveAll(x=>x.ProductId==productId);Save(c);return RedirectToAction(nameof(Index));}
}
