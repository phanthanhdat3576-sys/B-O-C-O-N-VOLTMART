using ElectronicPartsShop.Data;
using ElectronicPartsShop.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ElectronicPartsShop.Controllers;
public class HomeController(AppDbContext db) : Controller
{
 public async Task<IActionResult> Index() => View(new HomeIndexVm { Categories = await db.Categories.OrderBy(x=>x.Name).ToListAsync(), Featured = await db.Products.Where(x=>x.IsActive && x.IsFeatured).Include(x=>x.Category).Take(8).ToListAsync() });
}
