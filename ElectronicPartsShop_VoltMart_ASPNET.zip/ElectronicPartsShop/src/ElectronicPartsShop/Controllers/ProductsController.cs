using ElectronicPartsShop.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ElectronicPartsShop.Controllers;
public class ProductsController(AppDbContext db) : Controller
{
 public async Task<IActionResult> Index(string? q, int? categoryId)
 {
   var query=db.Products.Where(x=>x.IsActive).Include(x=>x.Category).AsQueryable();
   if(!string.IsNullOrWhiteSpace(q)){ q=q.Trim(); query=query.Where(x=>x.Name.Contains(q)|| (x.Brand??"").Contains(q)|| (x.Description??"").Contains(q)); }
   if(categoryId.HasValue) query=query.Where(x=>x.CategoryId==categoryId);
   ViewBag.Query=q; ViewBag.CategoryId=categoryId; ViewBag.Categories=await db.Categories.OrderBy(x=>x.Name).ToListAsync();
   return View(await query.OrderByDescending(x=>x.IsFeatured).ThenBy(x=>x.Name).ToListAsync());
 }
 public async Task<IActionResult> Details(int id){ var p=await db.Products.Include(x=>x.Category).FirstOrDefaultAsync(x=>x.Id==id && x.IsActive); return p is null?NotFound():View(p); }
}
