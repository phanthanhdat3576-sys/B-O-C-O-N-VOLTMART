using System.ComponentModel.DataAnnotations;
namespace ElectronicPartsShop.Models;
public enum OrderStatus { New, Confirmed, Shipping, Completed, Cancelled }
public class Order
{
    public int Id { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    [Required, StringLength(100)] public string CustomerName { get; set; } = string.Empty;
    [Required, Phone, StringLength(30)] public string Phone { get; set; } = string.Empty;
    [Required, StringLength(250)] public string Address { get; set; } = string.Empty;
    [EmailAddress, StringLength(120)] public string? Email { get; set; }
    [StringLength(600)] public string? Note { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.New;
    public decimal TotalAmount { get; set; }
    public ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
}
public class OrderItem
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    public int ProductId { get; set; }
    public Product? Product { get; set; }
    [Required, StringLength(140)] public string ProductName { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    [Range(1,999)] public int Quantity { get; set; }
}
