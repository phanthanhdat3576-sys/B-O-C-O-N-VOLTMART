using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace ElectronicPartsShop.Models;
public class Product
{
    public int Id { get; set; }
    [Required, StringLength(140)] public string Name { get; set; } = string.Empty;
    [StringLength(1000)] public string? Description { get; set; }
    [Range(0, 999999999)] public decimal Price { get; set; }
    [Range(0, 99999)] public int Stock { get; set; }
    [StringLength(200)] public string? ImageUrl { get; set; }
    [StringLength(80)] public string? Brand { get; set; }
    public bool IsFeatured { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    [Display(Name="Danh mục")] public int CategoryId { get; set; }
    public Category? Category { get; set; }
}
