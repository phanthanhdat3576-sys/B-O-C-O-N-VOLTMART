using ElectronicPartsShop.Models;
namespace ElectronicPartsShop.Data;
public static class DbInitializer
{
    public static void Initialize(AppDbContext db)
    {
        Directory.CreateDirectory("App_Data");
        db.Database.EnsureCreated();
        if (db.Categories.Any()) return;
        var cats = new[] {
            new Category{Name="Vi điều khiển",Description="Arduino, ESP32, Raspberry Pi"},
            new Category{Name="Cảm biến",Description="Nhiệt độ, độ ẩm, ánh sáng, chuyển động"},
            new Category{Name="Module",Description="Relay, Bluetooth, WiFi và module mở rộng"},
            new Category{Name="Nguồn điện",Description="Adapter, nguồn tổ ong, mạch hạ áp"},
            new Category{Name="Linh kiện thụ động",Description="Điện trở, tụ điện, diode"},
            new Category{Name="Dụng cụ - Thiết bị",Description="Mỏ hàn, đồng hồ đo, phụ kiện"}
        };
        db.Categories.AddRange(cats); db.SaveChanges();
        var p = new[] {
            new Product{Name="Arduino UNO R3 ATmega328P",Brand="Arduino",Price=125000,Stock=30,CategoryId=cats[0].Id,IsFeatured=true,ImageUrl="/images/products/arduino.svg",Description="Bo mạch UNO R3 dùng cho học tập và dự án IoT."},
            new Product{Name="ESP32 DevKit V4 WiFi + Bluetooth",Brand="Espressif",Price=135000,Stock=45,CategoryId=cats[0].Id,IsFeatured=true,ImageUrl="/images/products/esp32.svg",Description="Vi điều khiển ESP32 tích hợp WiFi và Bluetooth."},
            new Product{Name="Cảm biến DHT22 nhiệt độ độ ẩm",Brand="Aosong",Price=65000,Stock=50,CategoryId=cats[1].Id,IsFeatured=true,ImageUrl="/images/products/dht22.svg",Description="Cảm biến nhiệt độ, độ ẩm độ chính xác cao."},
            new Product{Name="Module Relay 1 kênh 5V",Brand="Songle",Price=45000,Stock=80,CategoryId=cats[2].Id,IsFeatured=true,ImageUrl="/images/products/relay.svg",Description="Relay cách ly điều khiển thiết bị điện."},
            new Product{Name="Nguồn tổ ong 12V 10A",Brand="MeanWell",Price=245000,Stock=16,CategoryId=cats[3].Id,IsFeatured=true,ImageUrl="/images/products/power.svg",Description="Nguồn switching 12V 10A, công suất 120W."},
            new Product{Name="Màn hình OLED 0.96 inch I2C",Brand="SSD1306",Price=85000,Stock=36,CategoryId=cats[2].Id,IsFeatured=true,ImageUrl="/images/products/oled.svg",Description="Màn hình OLED độ phân giải 128x64."},
            new Product{Name="Điện trở 1/4W 220 Ohm gói 100",Brand="Yageo",Price=5000,Stock=200,CategoryId=cats[4].Id,ImageUrl="/images/products/resistor.svg",Description="Điện trở than 220 Ohm, sai số 5%."},
            new Product{Name="Tụ điện 100uF 16V gói 50",Brand="Nichicon",Price=8000,Stock=150,CategoryId=cats[4].Id,ImageUrl="/images/products/capacitor.svg",Description="Tụ điện hoá chất lượng tốt."},
            new Product{Name="Mỏ hàn điều chỉnh nhiệt 60W",Brand="KSGER",Price=320000,Stock=12,CategoryId=cats[5].Id,ImageUrl="/images/products/solder.svg",Description="Mỏ hàn 60W điều chỉnh nhiệt, phù hợp thực hành."}
        };
        db.Products.AddRange(p); db.SaveChanges();
    }
}
