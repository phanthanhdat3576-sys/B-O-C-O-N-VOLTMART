using System.ComponentModel.DataAnnotations;
namespace ElectronicPartsShop.ViewModels;
public class CheckoutVm
{
 [Required(ErrorMessage="Vui lòng nhập họ tên"), Display(Name="Họ và tên")] public string CustomerName {get;set;}="";
 [Required(ErrorMessage="Vui lòng nhập số điện thoại"), Phone, Display(Name="Số điện thoại")] public string Phone {get;set;}="";
 [Required(ErrorMessage="Vui lòng nhập địa chỉ"), Display(Name="Địa chỉ nhận hàng")] public string Address {get;set;}="";
 [EmailAddress, Display(Name="Email")] public string? Email {get;set;}
 [Display(Name="Ghi chú")] public string? Note {get;set;}
}
