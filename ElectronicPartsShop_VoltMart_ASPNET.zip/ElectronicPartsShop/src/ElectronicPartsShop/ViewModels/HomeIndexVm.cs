using ElectronicPartsShop.Models;
namespace ElectronicPartsShop.ViewModels;
public class HomeIndexVm { public List<Category> Categories { get; set; } = []; public List<Product> Featured { get; set; } = []; }
