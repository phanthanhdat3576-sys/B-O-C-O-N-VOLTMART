# Mô hình dữ liệu (ERD)

```mermaid
erDiagram
  CATEGORY ||--o{ PRODUCT : "phân loại"
  ORDER ||--|{ ORDER_ITEM : "gồm"
  PRODUCT ||--o{ ORDER_ITEM : "được mua"
  CATEGORY { int Id PK string Name UK string Description }
  PRODUCT { int Id PK string Name decimal Price int Stock int CategoryId FK bool IsActive }
  ORDER { int Id PK datetime CreatedAt string CustomerName string Phone string Address decimal TotalAmount string Status }
  ORDER_ITEM { int Id PK int OrderId FK int ProductId FK string ProductName decimal UnitPrice int Quantity }
```
