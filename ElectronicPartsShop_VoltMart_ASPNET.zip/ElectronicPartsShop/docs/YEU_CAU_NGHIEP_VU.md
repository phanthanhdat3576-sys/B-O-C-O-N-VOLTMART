# Yêu cầu nghiệp vụ

## Tác nhân
- Khách hàng: tìm kiếm, xem chi tiết, thêm vào giỏ, đặt hàng.
- Quản trị viên: quản lý danh mục/sản phẩm, xử lý đơn, xem thống kê.

## Luồng đặt hàng
1. Khách tìm kiếm hoặc duyệt danh mục.
2. Chọn sản phẩm và số lượng.
3. Hệ thống lưu giỏ hàng trong Session.
4. Khách nhập thông tin giao nhận.
5. Hệ thống kiểm tra tồn kho, tạo đơn hàng, trừ tồn kho và thông báo mã đơn.

## Quy tắc dữ liệu
- Danh mục không được trùng tên.
- Không cho giá, tồn kho hoặc số lượng nhỏ hơn 0.
- Không xóa danh mục khi vẫn còn sản phẩm.
- Không tạo đơn hàng khi tồn kho không đủ.
