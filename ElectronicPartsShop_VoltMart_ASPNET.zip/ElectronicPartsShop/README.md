# VoltMart - Website bán linh kiện điện tử

Đồ án môn học Chuyên đề ASP.NET. Dự án xây dựng bằng **ASP.NET Core MVC + Entity Framework Core + SQLite**.

## Chức năng đáp ứng tiêu chí chấm
- Trang chủ thương mại điện tử, danh mục, sản phẩm nổi bật, khuyến mãi, tin tức.
- Tra cứu gần đúng theo tên, hãng hoặc mô tả sản phẩm.
- Giỏ hàng dùng Session; đặt hàng, kiểm tra tồn kho, lưu đơn hàng và chi tiết đơn hàng vào CSDL.
- Khu quản trị: đăng nhập, CRUD sản phẩm/danh mục, ẩn sản phẩm, cập nhật trạng thái đơn hàng.
- Báo cáo tổng số sản phẩm, số đơn, đơn trong ngày và doanh thu.
- Ràng buộc dữ liệu: tên danh mục duy nhất, giá/tồn kho/số lượng không âm, thông tin khách hàng bắt buộc, khóa ngoại đơn hàng - chi tiết đơn hàng - sản phẩm.

## Cài đặt
1. Cài .NET SDK 8.0 trở lên.
2. Mở thư mục `src/ElectronicPartsShop` bằng Visual Studio 2022 hoặc Terminal.
3. Chạy:
   ```bash
   dotnet restore
   dotnet run
   ```
4. Mở địa chỉ hiển thị trên Terminal, thường là `https://localhost:xxxx`.
5. CSDL SQLite tự tạo tại `App_Data/voltmart.db` và tự nạp dữ liệu mẫu ở lần chạy đầu.

## Tài khoản quản trị mẫu
- Tài khoản: `admin`
- Mật khẩu: `admin123`
- Có thể đổi ở `src/ElectronicPartsShop/appsettings.json`.

## Cấu trúc repository
- `src/ElectronicPartsShop`: mã nguồn.
- `setup`: hướng dẫn cài đặt.
- `progress-report`: báo cáo tiến độ hằng tuần.
- `thesis`: nơi lưu báo cáo, PDF, slide và tài liệu tham khảo.
- `docs`: yêu cầu nghiệp vụ, mô hình dữ liệu và sơ đồ.

## Lưu ý GitHub
Repository nên được đặt theo quy ước `ASPNET-<malop>-<hotenkhongdau>-VoltMart`, mời GVHD làm Collaborator, cập nhật README và commit ít nhất mỗi tuần một lần.
