Đặt slide, video bảo vệ tại đây.
