Đặt báo cáo PDF tại đây.
